from PyQt5 import QtCore, QtGui, QtWidgets, QtTest


class Ui_MainWindow(object):
    def setupUi(self, MainWindow):
        MainWindow.setObjectName("MainWindow")
        MainWindow.resize(800, 600)
        self.centralwidget = QtWidgets.QWidget(MainWindow)
        self.centralwidget.setObjectName("centralwidget")
        self.Glass_Position = QtWidgets.QFrame(self.centralwidget)
        self.Glass_Position.setGeometry(QtCore.QRect(380, 120, 301, 41))
        self.Glass_Position.setFrameShape(QtWidgets.QFrame.StyledPanel)
        self.Glass_Position.setFrameShadow(QtWidgets.QFrame.Raised)
        self.Glass_Position.setObjectName("Glass_Position")
        self.label_8 = QtWidgets.QLabel(self.Glass_Position)
        self.label_8.setGeometry(QtCore.QRect(20, 10, 271, 16))
        self.label_8.setObjectName("label_8")
        self.MixWith = QtWidgets.QFrame(self.centralwidget)
        self.MixWith.setGeometry(QtCore.QRect(570, 170, 151, 251))
        self.MixWith.setFrameShape(QtWidgets.QFrame.StyledPanel)
        self.MixWith.setFrameShadow(QtWidgets.QFrame.Raised)
        self.MixWith.setObjectName("MixWith")
        self.label_4 = QtWidgets.QLabel(self.MixWith)
        self.label_4.setGeometry(QtCore.QRect(50, 20, 80, 16))
        self.label_4.setObjectName("label_4")
        self.pushButton_9 = QtWidgets.QPushButton(self.MixWith)
        self.pushButton_9.setGeometry(QtCore.QRect(30, 70, 91, 31))
        self.pushButton_9.setObjectName("pushButton_9")
        self.pushButton_14 = QtWidgets.QPushButton(self.MixWith)
        self.pushButton_14.setGeometry(QtCore.QRect(30, 140, 91, 31))
        self.pushButton_14.setObjectName("pushButton_14")
        self.pushButton_18 = QtWidgets.QPushButton(self.MixWith)
        self.pushButton_18.setGeometry(QtCore.QRect(30, 210, 91, 31))
        self.pushButton_18.setObjectName("pushButton_18")
        self.ID_scan_Result = QtWidgets.QFrame(self.centralwidget)
        self.ID_scan_Result.setGeometry(QtCore.QRect(350, 60, 371, 51))
        self.ID_scan_Result.setFrameShape(QtWidgets.QFrame.StyledPanel)
        self.ID_scan_Result.setFrameShadow(QtWidgets.QFrame.Raised)
        self.ID_scan_Result.setObjectName("ID_scan_Result")
        self.label_6 = QtWidgets.QLabel(self.ID_scan_Result)
        self.label_6.setGeometry(QtCore.QRect(0, 2, 401, 47))
        self.label_6.setObjectName("label_6")
        self.ID_scan_Result_2 = QtWidgets.QFrame(self.ID_scan_Result)
        self.ID_scan_Result_2.setGeometry(QtCore.QRect(0, 50, 491, 51))
        self.ID_scan_Result_2.setFrameShape(QtWidgets.QFrame.StyledPanel)
        self.ID_scan_Result_2.setFrameShadow(QtWidgets.QFrame.Raised)
        self.ID_scan_Result_2.setObjectName("ID_scan_Result_2")
        self.NonAlcohol_2 = QtWidgets.QFrame(self.centralwidget)
        self.NonAlcohol_2.setGeometry(QtCore.QRect(440, 170, 120, 221))
        self.NonAlcohol_2.setFrameShape(QtWidgets.QFrame.StyledPanel)
        self.NonAlcohol_2.setFrameShadow(QtWidgets.QFrame.Raised)
        self.NonAlcohol_2.setObjectName("NonAlcohol_2")
        self.pushButton_16 = QtWidgets.QPushButton(self.NonAlcohol_2)
        self.pushButton_16.setGeometry(QtCore.QRect(20, 140, 91, 31))
        self.pushButton_16.setObjectName("pushButton_16")
        self.label_3 = QtWidgets.QLabel(self.NonAlcohol_2)
        self.label_3.setGeometry(QtCore.QRect(10, 20, 111, 16))
        self.label_3.setObjectName("label_3")
        self.pushButton_8 = QtWidgets.QPushButton(self.NonAlcohol_2)
        self.pushButton_8.setGeometry(QtCore.QRect(20, 70, 91, 31))
        self.pushButton_8.setObjectName("pushButton_8")
        self.Alcoholic_Drink = QtWidgets.QFrame(self.centralwidget)
        self.Alcoholic_Drink.setGeometry(QtCore.QRect(310, 170, 120, 221))
        self.Alcoholic_Drink.setFrameShape(QtWidgets.QFrame.StyledPanel)
        self.Alcoholic_Drink.setFrameShadow(QtWidgets.QFrame.Raised)
        self.Alcoholic_Drink.setObjectName("Alcoholic_Drink")
        self.Wine = QtWidgets.QPushButton(self.Alcoholic_Drink)
        self.Wine.setGeometry(QtCore.QRect(10, 140, 91, 31))
        self.Wine.setObjectName("Wine")
        self.Beer = QtWidgets.QPushButton(self.Alcoholic_Drink)
        self.Beer.setGeometry(QtCore.QRect(10, 70, 91, 31))
        self.Beer.setObjectName("Beer")
        self.AlcoholQn = QtWidgets.QLabel(self.Alcoholic_Drink)
        self.AlcoholQn.setGeometry(QtCore.QRect(20, 20, 80, 16))
        self.AlcoholQn.setObjectName("AlcoholQn")
        self.Result = QtWidgets.QFrame(self.centralwidget)
        self.Result.setGeometry(QtCore.QRect(320, 420, 171, 51))
        self.Result.setFrameShape(QtWidgets.QFrame.StyledPanel)
        self.Result.setFrameShadow(QtWidgets.QFrame.Raised)
        self.Result.setObjectName("Result")
        self.label_7 = QtWidgets.QLabel(self.Result)
        self.label_7.setGeometry(QtCore.QRect(10, 10, 141, 41))
        self.label_7.setObjectName("label_7")
        self.DrinkType = QtWidgets.QFrame(self.centralwidget)
        self.DrinkType.setGeometry(QtCore.QRect(90, 170, 211, 221))
        self.DrinkType.setFrameShape(QtWidgets.QFrame.StyledPanel)
        self.DrinkType.setFrameShadow(QtWidgets.QFrame.Raised)
        self.DrinkType.setObjectName("DrinkType")
        self.Drink_Label = QtWidgets.QLabel(self.DrinkType)
        self.Drink_Label.setGeometry(QtCore.QRect(10, 10, 191, 31))
        self.Drink_Label.setObjectName("Drink_Label")
        self.NonAlcohol = QtWidgets.QPushButton(self.DrinkType)
        self.NonAlcohol.setGeometry(QtCore.QRect(40, 140, 131, 31))
        self.NonAlcohol.setObjectName("NonAlcohol")
        self.Alcohol = QtWidgets.QPushButton(self.DrinkType)
        self.Alcohol.setGeometry(QtCore.QRect(40, 70, 131, 31))
        self.Alcohol.setObjectName("Alcohol")
        self.pushButton = QtWidgets.QPushButton(self.centralwidget)
        self.pushButton.setGeometry(QtCore.QRect(90, 60, 251, 101))
        self.pushButton.setObjectName("pushButton")
        MainWindow.setCentralWidget(self.centralwidget)
        self.menubar = QtWidgets.QMenuBar(MainWindow)
        self.menubar.setGeometry(QtCore.QRect(0, 0, 800, 21))
        self.menubar.setObjectName("menubar")
        MainWindow.setMenuBar(self.menubar)
        self.statusbar = QtWidgets.QStatusBar(MainWindow)
        self.statusbar.setObjectName("statusbar")
        MainWindow.setStatusBar(self.statusbar)

        self.retranslateUi(MainWindow)
        QtCore.QMetaObject.connectSlotsByName(MainWindow)

    def retranslateUi(self, MainWindow):
        _translate = QtCore.QCoreApplication.translate
        MainWindow.setWindowTitle(_translate("MainWindow", "Bartender"))
        self.label_8.setText(_translate("MainWindow", "Place Your glass"))
        self.label_4.setText(_translate("MainWindow", "Mix with?"))
        self.pushButton_9.setText(_translate("MainWindow", "Coke"))
        self.pushButton_14.setText(_translate("MainWindow", "Water"))
        self.pushButton_18.setText(_translate("MainWindow", "Ice"))
        self.label_6.setText(_translate("MainWindow", "Hey user, you are eligible / non eligible to drink"))
        self.pushButton_16.setText(_translate("MainWindow", "Water"))
        self.label_3.setText(_translate("MainWindow", "Non Alcoholic Drink"))
        self.pushButton_8.setText(_translate("MainWindow", "Coke"))
        self.Wine.setText(_translate("MainWindow", "Wine"))
        self.Beer.setText(_translate("MainWindow", "Beer"))
        self.AlcoholQn.setText(_translate("MainWindow", "Alcoholic Drink"))
        self.label_7.setText(_translate("MainWindow", "Hey user, Enjoy your drink"))
        self.Drink_Label.setText(_translate("MainWindow", "What drink would you love to have?"))
        self.NonAlcohol.setText(_translate("MainWindow", "Non alcoholic drink"))
        self.Alcohol.setText(_translate("MainWindow", "Alcoholic drink"))
        self.pushButton.setText(_translate("MainWindow", "Insert Your ID Card to scan"))

#Hiding Frames
        #self.ID_scan_Result.hide() #Hey user, you are eligible / non eligible to drink
        #self.Glass_Position.hide() #Place Your glass
        #self.DrinkType.hide() #What drink would you love to have?
        #self.Alcoholic_Drink.hide() #Alcoholic Drink
        #self.NonAlcohol_2.hide() #Non Alcoholic Drink
        #self.MixWith.hide() #Mix with?
        #self.Result.hide() #Hey user, Enjoy your drink

# adding action to each of the button
        self.pushButton.clicked.connect(self.action_pushButton)
        self.Alcohol.clicked.connect(self.action_Alcohol)
        self.NonAlcohol.clicked.connect(self.action_NonAlcohol)
        self.Beer.clicked.connect(self.action_Beer)
        self.Wine.clicked.connect(self.action_Wine)
        self.pushButton_8.clicked.connect(self.action_Coke)
        self.pushButton_16.clicked.connect(self.action_Water)
        self.pushButton_9.clicked.connect(self.action_MixCoke)
        self.pushButton_14.clicked.connect(self.action_MixWater)
        self.pushButton_18.clicked.connect(self.action_MixIce)

    def action_pushButton(self,checked):
        self.pushButton = checked
        print("Pushed ID Card Detection")
        self.ID_scan_Result.setText("asgyfgah")
        QtTest.QTest.qWait(10000)

    def action_Alcohol(self):
        print("Pushed Alcohol")

    def action_NonAlcohol(self):
        print("Pushed Non Alcohol")

    def action_Beer(self):
        print("Pushed Beer")

    def action_Wine(self):
        print("Pushed Wine")

    def action_Coke(self):
        print("Pushed Coke")

    def action_Water(self):
        print("Pushed Water")

    def action_MixCoke(self):
        print("Pushed MixCoke")

    def action_MixWater(self):
        print("Pushed MixWater")

    def action_MixIce(self):
        print("Pushed MixIce")

